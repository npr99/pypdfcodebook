# pypdfcodebook
A Python package for generating PDF codebooks from tabular data. Quickly create project descriptions, data dictionaries, and variable summaries with customizable formatting. Ideal for data science, reproducible research, and sharing dataset documentation.
