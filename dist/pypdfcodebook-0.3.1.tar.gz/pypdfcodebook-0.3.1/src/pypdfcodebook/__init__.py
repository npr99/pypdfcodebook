__version__ = "0.3.0"

def main():
    """Entry point for the application script"""
    print("Call your main application code here")
